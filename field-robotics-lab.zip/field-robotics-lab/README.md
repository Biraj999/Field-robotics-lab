# Field Robotics Lab

Small, runnable experiments in automation, robotics, and uncrewed aerial vehicles. Each project includes a reproducible demo, a project image, and a README that explains the engineering tradeoffs.

## Projects

| Project | Focus | Demo |
| --- | --- | --- |
| [Canopy Confidence](projects/canopy-confidence/) | UAV survey data | Rank crop plots for review using synthetic aerial imagery measurements and a cross-pass agreement check. |

The project agent rotates among the three topics and adds each experiment in its own folder. Demonstration data is synthetic or included with its source and license. UAV experiments use simulations or offline analysis.
